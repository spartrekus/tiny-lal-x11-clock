/*
    This file is part of lal.

    lal is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    lal is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with lal.  If not, see <http://www.gnu.org/licenses/>.

    Authors: Mikael Magnusson <mikachu@gmail.com>
             Dave Foster <daf@minuslab.net>
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xft/Xft.h>
#include <X11/Xresource.h>
#include <X11/StringDefs.h>
#include <time.h>
#include <signal.h>

int running = 0;
int windowwidth = 64;
int fontweight = 100;
double fontsize = 12.0;
char *fontname = "Mono";
char *timeformat = "%T";
char *colorname = "white";

#define NUM_OPTS 16
static XrmOptionDescRec opt_table[] = {
  {"--font",        "*font",        XrmoptionSepArg, (XPointer)NULL},
  {"--bold",        "*bold",        XrmoptionNoArg,  (XPointer)""},
  {"--fontsize",    "*fontsize",    XrmoptionSepArg, (XPointer)NULL},
  {"--color",       "*color",       XrmoptionSepArg, (XPointer)NULL},
  {"--width",       "*width",       XrmoptionSepArg, (XPointer)NULL},
  {"--format",      "*format",      XrmoptionSepArg, (XPointer)NULL},
  {"--help",        "*help",        XrmoptionNoArg,  (XPointer)""},
  {"--version",     "*version",     XrmoptionNoArg,  (XPointer)""},
  {"-t",            "*font",        XrmoptionSepArg, (XPointer)NULL},
  {"-b",            "*bold",        XrmoptionNoArg,  (XPointer)""},
  {"-s",            "*fontsize",    XrmoptionSepArg, (XPointer)NULL},
  {"-c",            "*color",       XrmoptionSepArg, (XPointer)NULL},
  {"-w",            "*width",       XrmoptionSepArg, (XPointer)NULL},
  {"-f",            "*format",      XrmoptionSepArg, (XPointer)NULL},
  {"-h",            "*help",        XrmoptionNoArg,  (XPointer)""},
  {"-v",            "*version",     XrmoptionNoArg,  (XPointer)""},
};

static void gettime(char *strtime)
{
  time_t curtime;
  struct tm *curtime_tm;

  curtime = time(NULL);
  curtime_tm = localtime(&curtime);
  strftime(strtime, 49, timeformat, curtime_tm);
}

void handle_term(int signal)
{
  running = 0;
}

void die(const char* str)
{
  fputs(str, stderr);
  fflush(stderr);
  exit(1);
}

void get_params(Display *display, int argc, char *argv[])
{
  XrmDatabase database;
  int nargc = argc;
  char **nargv = argv;
  char *type;
  XrmValue xrmval;
  char *xdefaults;

  XrmInitialize();
  database = XrmGetDatabase(display);
  
  /* merge in Xdefaults */
  xdefaults = malloc(strlen(getenv("HOME")) + strlen("/.Xdefaults") + 1);
  sprintf(xdefaults, "%s/.Xdefaults", getenv("HOME"));
  XrmCombineFileDatabase(xdefaults, &database, True);
  free(xdefaults);

  /* parse command line */
  XrmParseCommand(&database, opt_table, NUM_OPTS, "lal", &nargc, nargv);

  /* check for help option */
  if (XrmGetResource(database, "lal.help", "lal.help", &type, &xrmval) == True)
  {
    printf("Usage: lal [options]\n\n");
    printf("Options:\n");
    printf("-v, --version:    Print version information\n");
    printf("-h, --help:       This text\n");
    printf("-t, --font:       The font face to use.  Default is Mono.\n");
    printf("-b, --bold:       Use a bold font.\n");
    printf("-s, --fontsize:   The font size to use.  Default is 12.0.\n");
    printf("-c, --color:      The font color to use.  Default is white.\n");
    printf("-w, --width:      The width of the dockapp window.  Default is 64.\n");
    printf("-f, --format:     The time format to use.  Default is %%T.  You can\n");
    printf("                  get format codes from the man page for strftime.\n\n");
    printf("You can also put these in your ~/.Xdefaults file:\n");
    printf("lal*font\n");
    printf("lal*bold\n");
    printf("lal*fontsize\n");
    printf("lal*color\n");
    printf("lal*width\n");
    printf("lal*format\n\n");
    exit(0);
  }

  /* check for version request */
  if (XrmGetResource(database, "lal.version", "lal.version", &type, &xrmval) == True)
  {
    printf("lal 1.1\n");
    exit(0);
  }

  /* get options out of it */
  if (XrmGetResource(database, "lal.font", "lal.font", &type, &xrmval) == True)
  {
    if (strcmp(type, "String")) 
      die("Option \"font\" was in an unexpected format!");
    fontname = xrmval.addr;
  }

  if (XrmGetResource(database, "lal.bold", "lal.bold", &type, 
                     &xrmval) == True)
  {
    fontweight = 200; /* 200 means bold */
  }

  if (XrmGetResource(database, "lal.fontsize", "lal.fontsize", &type, 
                     &xrmval) == True)
  {
    if (strcmp(type, "String")) 
      die("Option \"fontsize\" was in an unexpected format!");
    fontsize = strtod(xrmval.addr, NULL);
  }

  if (XrmGetResource(database, "lal.color", "lal.color", &type, 
                     &xrmval) == True)
  {
    if (strcmp(type, "String"))
      die("Option \"color\" was in an unexpected format!");
    colorname = xrmval.addr;
  }

  if (XrmGetResource(database, "lal.width", "lal.width", &type, 
                     &xrmval) == True)
  {
    if (strcmp(type, "String")) 
      die("Option \"width\" was in an unexpected format!");
    windowwidth = strtod(xrmval.addr, NULL);
  }

  if (XrmGetResource(database, "lal.format", "lal.format", &type, 
                     &xrmval) == True)
  {
    if (strcmp(type, "String"))
      die("Option \"format\" was in an unexpected format!");
    timeformat = xrmval.addr;
  }  
}

int main(int argc, char *argv[])
{
  /* X stuff */
  Display *display;
  Window dockapp;
  XWMHints wm_hints;
  XftFont *font;
  XftDraw *draw;
  XftColor xftcolor;
  XRenderColor color;
  XColor c; /* ... */
  int screen;
  Colormap colormap;
  Window root;
  Visual *vis;
  XGlyphInfo extents;
  XEvent event;
  int x, y;

  /* Time stuff */
  int xfd, selectret = 0;
  fd_set fds;
  struct timeval timeout;
  char strtime[50];

  struct sigaction act;

  act.sa_handler = &handle_term;
  sigaction(SIGTERM, &act, NULL);
  sigaction(SIGINT, &act, NULL);
  running = 1;

  display = XOpenDisplay(NULL);
  if (!display) {
    fprintf(stderr, "Couldn't open X\n");
    fflush(stderr);
    exit(1);
  }

  /* command line/xresources: sets fonts etc */
  get_params(display, argc, argv); 

  xfd = ConnectionNumber(display);
  if (xfd == -1) {
    fprintf(stderr, "Couldn't get X filedescriptor\n");
    fflush(stderr);
    exit(1);
  }

  screen = DefaultScreen(display);
  colormap = DefaultColormap(display, screen);
  root = DefaultRootWindow(display);
  vis = DefaultVisual(display, screen);
  dockapp = XCreateSimpleWindow(display, root, 0, 0, windowwidth, 24, 0, 0, 0);

  wm_hints.initial_state = WithdrawnState;
  wm_hints.icon_window = wm_hints.window_group = dockapp;
  wm_hints.flags = StateHint | IconWindowHint;
  XSetWMHints(display, dockapp, &wm_hints);
  XSetCommand(display, dockapp, argv, argc);

  XSetWindowBackgroundPixmap(display, dockapp, ParentRelative);

  gettime(strtime);
  font = XftFontOpen(display, screen,
                     XFT_FAMILY, XftTypeString, fontname,
                     XFT_WEIGHT, XftTypeInteger, fontweight,
                     XFT_PIXEL_SIZE, XftTypeDouble, fontsize, NULL);
  XftTextExtents8(display, font, (unsigned char*)strtime, strlen(strtime), &extents);
  x = (windowwidth-extents.width)/2 + extents.x;
  y = (24-extents.height)/2 + extents.y;
  if (x < 0 || y < 0) {
    fprintf(stderr, "Uh oh, text doesn't fit inside window\n");
    fflush(stderr);
  }
  draw = XftDrawCreate(display, dockapp, vis, colormap);
  if (XParseColor(display, colormap, colorname, &c) == None) {
    fprintf(stderr, "Couldn't parse color '%s'\n", colorname);
    fflush(stderr);
    color.red = 0xffff;
    color.green = 0xffff;
    color.blue = 0xffff;
  } else {
    color.red = c.red;
    color.blue = c.blue;
    color.green = c.green;
  }
  color.alpha = 0xffff;
  XftColorAllocValue(display, vis, colormap, &color, &xftcolor);

  XSelectInput(display, dockapp, ExposureMask);
  XMapWindow(display, dockapp);
  XFlush(display);

  timeout.tv_sec = timeout.tv_usec = 0;
  while (running) {
    FD_ZERO(&fds);
    FD_SET(xfd, &fds);

    selectret = select(xfd+1, &fds, NULL, NULL, &timeout);

    switch (selectret) {
    case -1:
      continue;
    case 0:
      gettime(strtime);
      XClearWindow(display, dockapp);
      XftDrawString8(draw, &xftcolor, font, x, y, (unsigned char*)strtime, strlen(strtime));
      XFlush(display);
      timeout.tv_sec = 1;
      timeout.tv_usec = 0;
    case 1:
      if (FD_ISSET(xfd, &fds)) {
        XNextEvent(display, &event);
        switch (event.type) {
        case Expose:
          XClearWindow(display, dockapp);
          XftDrawString8(draw, &xftcolor, font, x, y, (unsigned char*)strtime, strlen(strtime));
          XFlush(display);
        }
      }
    }
  }

  XftFontClose(display, font);
  XftDrawDestroy(draw);
  XCloseDisplay(display);

  return 0;
}
